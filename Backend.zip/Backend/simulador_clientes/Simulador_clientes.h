#ifndef SIMULADOR_CLIENTES_H
#define SIMULADOR_CLIENTES_H

void generarClienteSimulado();

#endif