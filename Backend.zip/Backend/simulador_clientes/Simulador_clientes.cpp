#include <iostream>
#include <vector>
#include <string>
#include "nlohmann/json.hpp"
using json = nlohmann::json;

using namespace std;
void generarClienteSimulado() {
    vector <string> nombres = {"Ana", "Luis", "Emma", "Carlos","jose","julio","Dennis"};
    vector <string> eventos = {"Spa", "Restaurant", "Conferencia","paseo en cayac"};
    
    string nombre = nombres[rand() % nombres.size()];
    string evento = eventos[rand() % eventos.size()];

    json j = {
        {"nombre", nombre},
        {"fecha_ingreso", "2025-06-12"},
        {"fecha_salida", "2025-06-15"},
        {"evento", evento}
    };

    string json_str = j.dump();
    cout << "JSON generado:\n" << j.dump(2) << endl;

    // Enviar este JSON al servidor local (localhost:8080/api/reservas)
    // usando sockets o librería HTTP (como cpr o httplib si quieres hacerlo más elegante)(investigar)
}
