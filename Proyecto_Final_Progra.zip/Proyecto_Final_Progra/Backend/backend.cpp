// backend.cpp
#include "backend.h"
#include <string>
#include "Modelado_hotel/Modelado_hotel.h"
#include "pathfinding/pathfinding.h"
#include "Modelado_hotel/Grafos_hotel.h"

 Hotel hotel(10, 10);
static GrafoHotel grafo;
static bool grafo_inicializado = false;

json procesarReserva(const json& j) {
    if (!j.contains("nombre") || !j.contains("fecha_ingreso") ||
        !j.contains("fecha_salida") || !j.contains("evento") || !j.contains("tipo")) {
        return {
            {"success", false},
            {"mensaje", "Faltan campos obligatorios"}
        };
    }

    if (!grafo_inicializado) {
        construirGrafo(grafo, 10, 10);
        grafo_inicializado = true;
    }

    std::string tipo = j["tipo"];
    Habitacion* hab = hotel.buscarHabitacionDisponible(tipo);
    if (!hab) {
        return {
            {"success", false},
            {"mensaje", "Lo sentimos, no hay habitaciones disponibles"}
        };
    }

    hab->ocupada = true;
    static int id = 1;

    // Generar lista de habitaciones ocupadas
    std::vector<json> ocupadas_json;
    for (int p = 0; p < 10; ++p) {
        for (int h = 0; h < 10; ++h) {
            Habitacion& actual = hotel.getHabitacion(p, h);
            if (actual.ocupada) {
                ocupadas_json.push_back({{"piso", p}, {"habitacion", h}});
            }
        }
    }

    // Calcular ruta desde recepción (0,0) hasta la habitación asignada
    Nodo entrada = {0, 0};
    Nodo destino = {hab->piso, hab->numero};
    auto ruta = dijkstraCaminoMasCorto(grafo, entrada, destino);

    std::vector<json> ruta_json;
    for (const auto& paso : ruta) {
        ruta_json.push_back({{"piso", paso.piso}, {"habitacion", paso.habitacion}});
    }

    return {
        {"success", true},
        {"reserva_id", id++},
        {"habitacion", {
            {"piso", hab->piso},
            {"numero", hab->numero}
        }},
        {"ruta", ruta_json},
        {"ocupadas", ocupadas_json},
        {"mensaje", "Reserva exitosa para " + std::string(j["nombre"])}
    };
}
