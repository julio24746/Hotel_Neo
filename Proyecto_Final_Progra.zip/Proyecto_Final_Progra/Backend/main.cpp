#include<iostream>
#include <cstdlib>
#include <ctime>
#include "Simulador_clientes.h"

int main() {
    srand(time(NULL));
    generarClienteSimulado();
    return 0;
}
